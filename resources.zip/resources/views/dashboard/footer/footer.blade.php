<footer class="main-footer">
    <strong>Copyright &copy; 2023 <a href="https://inventory.heritagebd.net/">ICD HS</a>.</strong>
    All rights reserved. Developed by <strong>Heritage Innovation Center</strong>
    <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 1.0.0
    </div>
</footer>
